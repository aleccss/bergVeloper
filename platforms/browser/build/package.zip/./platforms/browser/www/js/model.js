function Model(){
  this.name = "asd";
}
