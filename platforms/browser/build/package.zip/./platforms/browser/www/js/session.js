var Session = {
	restaurants : null,
	users : null,
	setRestaurants : function(restaurants){
		this.restaurants = restaurants;
	},
	setUsers : function(users){
		this.users = users;
	}
}
